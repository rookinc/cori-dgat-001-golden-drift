#!/usr/bin/env python3
"""GPH-048B.1: exact golden spectrum and history source gate."""

import json
from pathlib import Path

import sympy as sp

ROOT = Path.cwd()
NATIVE = (
    ROOT / "46-native-g60-hodge-mechanics"
    / "data/g9000/native.json"
)

native = json.loads(NATIVE.read_text())
edges = native["edges"]

print("=== NATIVE G60 ADJACENCY ===")
print("Edge count:", len(edges))

A = sp.zeros(60)

for u, v in edges:
    u, v = int(u), int(v)
    A[u, v] = 1
    A[v, u] = 1

assert len(edges) == 120
assert all(A[i, i] == 0 for i in range(60))
assert all(sum(A.row(i)) == 4 for i in range(60))

x = sp.Symbol("x")
charpoly = sp.factor(A.charpoly(x).as_expr())

print("Characteristic polynomial:")
print(charpoly)

gold_factor = x*x - 2*x - 4
quotient, remainder = sp.div(
    charpoly, gold_factor**6, x
)

gold_spectrum_pass = remainder == 0
extra_multiplicity = sp.rem(
    quotient, gold_factor, x
) == 0

print("Golden factor power 6:", gold_spectrum_pass)
print("Additional golden factor:", extra_multiplicity)

# Exact 12-dimensional invariant subspace.
G = A - sp.eye(60)
E = G*G - 5*sp.eye(60)

gold_kernel = E.nullspace()
gold_dim = len(gold_kernel)

print("Golden kernel dimension:", gold_dim)

gold_gate = (
    gold_spectrum_pass
    and not extra_multiplicity
    and gold_dim == 12
)

print("Golden spectral gate:", gold_gate)

print("\n=== HISTORY SOURCE LOCATOR ===")

terms = (
    "registered_history_conference",
    "history_clifford",
    "history_incidence",
    "registered_pentagon",
)

matches = []

for root in (
    ROOT / "41-order-4-dodecahedral-residue",
    ROOT / "46-native-g60-hodge-mechanics",
    ROOT / "quantum-relativity",
):
    if not root.exists():
        continue

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if ".git" in path.parts:
            continue
        if path.suffix.lower() not in (
            ".json", ".py", ".npz", ".npy"
        ):
            continue
        if any(t in path.name.lower() for t in terms):
            matches.append(str(path.relative_to(ROOT)))

for path in sorted(set(matches))[:60]:
    print(path)

print("\n=== AUDIT RESULT ===")

report = {
    "audit": "GPH-048B.1",
    "native_graph": "AT4val[60,6] source edge list",
    "vertex_count": 60,
    "edge_count": len(edges),
    "golden_factor": "x^2 - 2*x - 4",
    "golden_multiplicity_each": 6 if gold_gate else None,
    "golden_kernel_dimension": gold_dim,
    "golden_spectral_gate": bool(gold_gate),
    "history_source_candidates": sorted(set(matches)),
    "native_history_intertwiner_found": False,
    "status": (
        "exact_spectral_gate_passed_crosswalk_open"
        if gold_gate else
        "golden_spectral_gate_failed"
    ),
}

out = ROOT / "gph048b_golden_source_gate.json"
out.write_text(json.dumps(report, indent=2) + "\n")

print(json.dumps({
    "audit": report["audit"],
    "golden_spectral_gate": report["golden_spectral_gate"],
    "golden_kernel_dimension": gold_dim,
    "history_source_candidate_count": len(set(matches)),
    "status": report["status"],
}, indent=2))

print("WROTE:", out)
