#!/usr/bin/env python3
"""GPH-048J.1: exact native pentagon cycle-lattice audit."""

import json
from pathlib import Path
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ

ROOT = Path.cwd()

p = ROOT / (
    "43-registered-carrier-language/artifacts/json/"
    "g60-registered-carrier-automaton-089.json"
)

rows = json.loads(p.read_text())["pentagon_rows"]

assert len(rows) == 12

cycles = [r["base_cycle"] for r in rows]
holonomies = [r["computed_holonomy"] for r in rows]

# Recover the undirected G15 edge universe.
edges = sorted({
    tuple(sorted((cycle[i], cycle[(i+1) % 5])))
    for cycle in cycles
    for i in range(5)
})

edge_index = {edge: i for i, edge in enumerate(edges)}

print("G15 edge count:", len(edges))
assert len(edges) == 30

# Signed edge-cycle incidence.
B = sp.zeros(30, 12)

for j, cycle in enumerate(cycles):
    for i in range(5):
        u = cycle[i]
        v = cycle[(i+1) % 5]

        edge = tuple(sorted((u, v)))
        sign = 1 if (u, v) == edge else -1

        B[edge_index[edge], j] += sign

# Verify every column is a closed cycle.
boundary = sp.zeros(15, 30)

for j, (u, v) in enumerate(edges):
    boundary[u, j] = -1
    boundary[v, j] = 1

assert boundary * B == sp.zeros(15, 12)

rank_q = B.rank()

# Smith normal form over integers.
S = smith_normal_form(B, domain=ZZ)

smith = [
    abs(int(S[i, i]))
    for i in range(min(S.rows, S.cols))
    if S[i, i] != 0
]

rank_f2 = sum(x % 2 == 1 for x in smith)

print("Rank over Q:", rank_q)
print("Rank over F2:", rank_f2)
print("Smith diagonal:", smith)
print("Holonomy counts:", {
    "b": holonomies.count("b"),
    "ab": holonomies.count("ab"),
})

lattice = json.loads((
    ROOT /
    "41-order-4-dodecahedral-residue/source/"
    "201h71i/registered_pentagon_history_lattice.json"
).read_text())

expected = lattice["registered_pentagon_submodule"]

checks = {
    "twelve_generators": len(cycles) == 12,
    "thirty_edges": len(edges) == 30,
    "closed_integer_cycles":
        boundary * B == sp.zeros(15, 12),
    "rational_rank_matches":
        rank_q == expected["rank_over_Q"],
    "mod2_rank_matches":
        rank_f2 == expected["rank_mod_2"],
    "smith_diagonal_matches":
        smith == expected["smith_nonzero_diagonal"],
    "six_b_six_ab":
        holonomies.count("b") ==
        holonomies.count("ab") == 6,
}

report = {
    "audit": "GPH-048J.1",
    "checks": checks,
    "all_checks_pass": all(checks.values()),
    "rank_over_Q": rank_q,
    "rank_mod2": rank_f2,
    "smith_diagonal": smith,
    "cycles": cycles,
    "holonomies": holonomies,
    "edge_order": edges,
    "incidence_matrix": [
        list(map(int, B.row(i)))
        for i in range(B.rows)
    ],
    "boundary": (
        "Exact integral cycle invariants only. "
        "Matching Smith data does not prove native "
        "identity with the archived history lattice, "
        "nor an intertwiner into G60 golden adjacency."
    ),
}

out = ROOT / "gph048j_native_cycle_lattice.json"
out.write_text(json.dumps(report, indent=2) + "\n")

print("\n=== CHECKS ===")
for key, value in checks.items():
    print(key, value)

print("\nVERDICT:",
      "MATCHED_LATTICE_INVARIANTS"
      if report["all_checks_pass"]
      else "LATTICE_INVARIANT_MISMATCH")

print("WROTE:", out)
