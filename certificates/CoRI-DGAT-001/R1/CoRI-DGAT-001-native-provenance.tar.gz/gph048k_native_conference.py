#!/usr/bin/env python3
"""GPH-048K: exact native pentagon Gram/conference audit."""

import json
from pathlib import Path
import sympy as sp

ROOT = Path.cwd()

source = json.loads(
    (ROOT / "gph048j_native_cycle_lattice.json").read_text()
)

B = sp.Matrix(source["incidence_matrix"])
assert B.shape == (30, 12)

G = B.T * B
K = G - 5 * sp.eye(12)

conference_identity = (
    K * K == 5 * sp.eye(12)
)

print("=== NATIVE PENTAGON GRAM ===")
print("Matrix shape:", G.shape)
print("Gram diagonal:", list(G.diagonal()))
print("Conference identity:", conference_identity)

print("\n=== CENTERED GRAM SPECTRUM ===")
print("Characteristic polynomial:")
print(sp.factor(K.charpoly().as_expr()))

print("\n=== HOLONOMY BLOCK STRUCTURE ===")

holonomies = source["holonomies"]

b_indices = [
    i for i, h in enumerate(holonomies)
    if h == "b"
]

ab_indices = [
    i for i, h in enumerate(holonomies)
    if h == "ab"
]

print("b indices:", b_indices)
print("ab indices:", ab_indices)

Kbb = K.extract(b_indices, b_indices)
Kaa = K.extract(ab_indices, ab_indices)
C = K.extract(b_indices, ab_indices)

same_sheet_zero = (
    Kbb == sp.zeros(6)
    and Kaa == sp.zeros(6)
)

cross_block_conference = (
    C * C.T == 5 * sp.eye(6)
    and C.T * C == 5 * sp.eye(6)
)

print("Same-sheet blocks zero:", same_sheet_zero)
print("Cross-block conference:", cross_block_conference)

print("\n=== CROSS BLOCK ===")
print(C)

checks = {
    "incidence_shape": B.shape == (30, 12),
    "gram_diagonal_five":
        all(G[i, i] == 5 for i in range(12)),
    "conference_identity": conference_identity,
    "same_sheet_blocks_zero": same_sheet_zero,
    "cross_block_conference": cross_block_conference,
}

report = {
    "audit": "GPH-048K",
    "checks": checks,
    "all_checks_pass": all(checks.values()),
    "b_indices": b_indices,
    "ab_indices": ab_indices,
    "gram_matrix": [
        [int(G[i,j]) for j in range(12)]
        for i in range(12)
    ],
    "centered_gram_matrix": [
        [int(K[i,j]) for j in range(12)]
        for i in range(12)
    ],
    "cross_block": [
        [int(C[i,j]) for j in range(6)]
        for i in range(6)
    ],
    "boundary": (
        "Exact native G15 cycle Gram audit. "
        "Conference identity, if proved, does not "
        "by itself establish an incidence intertwiner "
        "into the G60 golden adjacency sector."
    ),
}

out = ROOT / "gph048k_native_conference.json"
out.write_text(json.dumps(report, indent=2) + "\n")

print("\n=== VERDICT ===")
print(
    "NATIVE_CONFERENCE_RECONSTRUCTED"
    if report["all_checks_pass"]
    else "CONFERENCE_RECONSTRUCTION_FAILED"
)

print("WROTE:", out)
