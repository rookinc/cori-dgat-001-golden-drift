#!/usr/bin/env python3
"""GPH-048L.1: exact lifted-cycle golden projection gate."""

import json
from pathlib import Path
import sympy as sp

ROOT = Path.cwd()

def load(path):
    return json.loads((ROOT / path).read_text())

native = load(
    "46-native-g60-hodge-mechanics/data/g9000/native.json"
)
lifts = load(
    "43-registered-carrier-language/source/"
    "native_g60_pentagon_holonomy_lift_audit_060.json"
)
conference = load("gph048k_native_conference.json")

A = sp.zeros(60)
for u, v in native["edges"]:
    u, v = int(u), int(v)
    A[u, v] = A[v, u] = 1

T = A - sp.eye(60)
K = sp.Matrix(conference["centered_gram_matrix"])

assert K.shape == (12, 12)
assert K*K == 5*sp.eye(12)

# Exact golden eigenspace and orthogonal projector.
W = sp.Matrix.hstack(
    *((T*T - 5*sp.eye(60)).nullspace())
)
assert W.shape == (60, 12)

P = W * (W.T*W).inv() * W.T

assert P*P == P
assert P.T == P
assert T*P == P*T

rows = lifts["pentagon_rows"]
assert len(rows) == 12

S = sp.zeros(60, 12)
D = sp.zeros(60, 12)

for j, row in enumerate(rows):
    cycles = row["distinct_lifted_cycles"]

    if len(cycles) != 2:
        raise ValueError(
            f"Pentagon {j}: expected two lifted cycles"
        )

    vectors = []

    for cycle in cycles:
        if isinstance(cycle, dict):
            cycle = cycle.get(
                "lifted_cycle",
                cycle.get("vertices")
            )

        if not isinstance(cycle, list):
            raise ValueError(
                f"Pentagon {j}: unexpected cycle format"
            )

        if len(cycle) != 10:
            raise ValueError(
                f"Pentagon {j}: expected a decagon"
            )

        v = sp.zeros(60, 1)

        for vertex in cycle:
            vertex = int(vertex)
            assert 0 <= vertex < 60
            v[vertex] += 1

        vectors.append(v)

    S[:, j] = vectors[0] + vectors[1]
    D[:, j] = vectors[0] - vectors[1]

def audit(name, U):
    projected = P*U

    raw_residual = T*U - U*K
    projected_residual = T*projected - projected*K

    result = {
        "raw_rank": U.rank(),
        "golden_projection_rank": projected.rank(),
        "raw_intertwines": raw_residual.is_zero_matrix,
        "projected_intertwines":
            projected_residual.is_zero_matrix,
        "golden_component_nonzero":
            not projected.is_zero_matrix,
        "golden_component_full_rank":
            projected.rank() == 12,
        "raw_image_entirely_golden":
            P*U == U,
    }

    print("\n===", name, "===")
    for key, value in result.items():
        print(key, value)

    return result

print("=== GPH-048L.1 ===")
print("Golden eigenspace dimension:", W.cols)

results = {
    "unsigned_lift_sum": audit("UNSIGNED SUM", S),
    "lift_difference": audit("LIFT DIFFERENCE", D),
}

report = {
    "audit": "GPH-048L.1",
    "golden_dimension": W.cols,
    "results": results,
    "boundary": [
        "Candidate maps are native vertex-support readouts.",
        "Lift ordering is not a canonical orientation.",
        "Golden projection is a spectral diagnostic, "
        "not an incidence-derived intertwiner.",
        "A projected rank-12 image alone does not "
        "establish operator intertwining.",
        "No physical or geometric quarter-turn claim."
    ]
}

out = ROOT / "gph048l_lifted_golden_gate.json"
out.write_text(json.dumps(report, indent=2) + "\n")

print("\nWROTE:", out)
