#!/usr/bin/env python3
"""GPH-048M: exact golden transport in native lift coordinates."""

import json
from pathlib import Path
import sympy as sp

ROOT = Path.cwd()

def load(path):
    return json.loads((ROOT / path).read_text())

native = load(
    "46-native-g60-hodge-mechanics/data/g9000/native.json"
)

lifts = load(
    "43-registered-carrier-language/source/"
    "native_g60_pentagon_holonomy_lift_audit_060.json"
)

conference = load("gph048k_native_conference.json")

A = sp.zeros(60)

for u, v in native["edges"]:
    A[u, v] = A[v, u] = 1

T = A - sp.eye(60)
K = sp.Matrix(conference["centered_gram_matrix"])

D = sp.zeros(60, 12)

for j, row in enumerate(lifts["pentagon_rows"]):
    cycles = row["distinct_lifted_cycles"]
    assert len(cycles) == 2

    for sign, cycle in zip((1, -1), cycles):
        if isinstance(cycle, dict):
            cycle = cycle.get(
                "lifted_cycle", cycle.get("vertices")
            )

        assert len(cycle) == 10

        for vertex in cycle:
            D[int(vertex), j] += sign

assert D.rank() == 12

H = D.T * D
M = H.inv() * D.T * T * D

checks = {
    "golden_basis_rank_12": D.rank() == 12,
    "native_transport_closure": T*D == D*M,
    "native_transport_golden_identity":
        M*M == 5*sp.eye(12),
    "history_conference_identity":
        K*K == 5*sp.eye(12),
    "direct_operator_equality": M == K,
    "operator_commutation": M*K == K*M,
    "operator_anticommutation":
        M*K == -K*M,
    "transport_self_adjoint_in_lift_metric":
        M.T*H == H*M,
}

print("=== GPH-048M ===")

for key, value in checks.items():
    print(key, value)

print("\n=== LIFT METRIC ===")
print(H)

print("\n=== NATIVE GOLDEN TRANSPORT ===")
print(M)

print("\n=== COMPARISON ===")
print("M-K rank:", (M-K).rank())
print("M+K rank:", (M+K).rank())
print("M characteristic polynomial:",
      sp.factor(M.charpoly().as_expr()))
print("K characteristic polynomial:",
      sp.factor(K.charpoly().as_expr()))

def encode(X):
    return [
        [str(X[i,j]) for j in range(X.cols)]
        for i in range(X.rows)
    ]

report = {
    "audit": "GPH-048M",
    "checks": checks,
    "lift_metric": encode(H),
    "native_transport_matrix": encode(M),
    "history_conference_matrix": encode(K),
    "difference_rank": (M-K).rank(),
    "sum_rank": (M+K).rank(),
    "boundary": [
        "Native golden lift basis established.",
        "M is the exact adjacency action in lift coordinates.",
        "M and K need not agree in their current bases.",
        "No canonical conference-to-lift basis change claimed.",
        "No physical rotation or transport claim."
    ]
}

out = ROOT / "gph048m_native_transport_matrix.json"
out.write_text(json.dumps(report, indent=2) + "\n")

print("\nWROTE:", out)
