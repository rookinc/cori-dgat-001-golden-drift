#!/usr/bin/env python3
"""GPH-048O.1: exact dual-golden product classification."""

import json
from pathlib import Path
import sympy as s

ROOT = Path.cwd()
src = json.loads(
    (ROOT / "gph048m_native_transport_matrix.json").read_text()
)

M = s.Matrix(src["native_transport_matrix"])
K = s.Matrix(src["history_conference_matrix"])
I = s.eye(12)

b = [0, 3, 5, 7, 9, 10]
ab = [1, 2, 4, 6, 8, 11]

Z = s.diag(*[1 if i in b else -1 for i in range(12)])

assert M*M == 5*I
assert K*K == 5*I
assert M == M.T and K == K.T

Q = M*K/5
x = s.Symbol("x")

# Exact minimal polynomial, using linear dependence
# among matrix powers over the rational numbers.
def matrix_minpoly(T):
    powers = [s.eye(T.rows)]
    columns = [s.Matrix(powers[0]).reshape(T.rows**2, 1)]

    for degree in range(1, T.rows*T.rows+1):
        powers.append(powers[-1]*T)
        new = powers[-1].reshape(T.rows**2, 1)
        previous = s.Matrix.hstack(*columns)
        solution, parameters = previous.gauss_jordan_solve(new) \
            if previous.rank() == s.Matrix.hstack(previous, new).rank() \
            else (None, None)

        if solution is not None:
            if parameters:
                solution = solution.subs({
                    p: 0 for p in parameters
                })
            poly = x**degree - sum(
                solution[i]*x**i for i in range(degree)
            )
            return s.factor(poly)

        columns.append(new)

    raise RuntimeError("Minimal polynomial not found")

charpoly = s.factor(Q.charpoly(x).as_expr())
minpoly = matrix_minpoly(Q)

print("=== GPH-048O ===")
print("Q = MK/5")
print("Characteristic polynomial:", charpoly)
print("Minimal polynomial:", minpoly)

checks = {
    "orthogonal": Q.T*Q == I,
    "grading_reversing": Z*Q == -Q*Z,
    "even_characteristic_polynomial":
        s.expand(charpoly.subs(x, -x)-charpoly) == 0,
    "square_preserves_grading": Z*Q**2 == Q**2*Z,
    "determinant_unit": abs(Q.det()) == 1,
}

for name, result in checks.items():
    print(name, result)

print("det(Q):", Q.det())
print("trace(Q):", s.trace(Q))
print("trace(Q^2):", s.trace(Q**2))
print("trace(Q^4):", s.trace(Q**4))

# Exact finite-order search.
MAX_ORDER = 240
power = I
order = None

for n in range(1, MAX_ORDER+1):
    power = power*Q
    if power == I:
        order = n
        break

print("Finite order <= 240:", order)

# Test whether the minimal polynomial consists
# entirely of cyclotomic factors.
factors = s.factor_list(minpoly, x)[1]
cyclotomic_factors = []

for factor, multiplicity in factors:
    found = None
    for n in range(1, 481):
        if s.expand(factor-s.cyclotomic_poly(n, x)) == 0:
            found = n
            break
    cyclotomic_factors.append({
        "factor": str(factor),
        "multiplicity": multiplicity,
        "cyclotomic_index": found,
    })

all_cyclotomic = all(
    row["cyclotomic_index"] is not None
    for row in cyclotomic_factors
)

print("All factors cyclotomic:", all_cyclotomic)
print("Cyclotomic factors:", cyclotomic_factors)

print("rank(Q^2+I):", (Q**2+I).rank())
print("rank(Q^4-I):", (Q**4-I).rank())

report = {
    "audit": "GPH-048O.1",
    "checks": checks,
    "characteristic_polynomial": str(charpoly),
    "minimal_polynomial": str(minpoly),
    "determinant": str(Q.det()),
    "trace": str(s.trace(Q)),
    "trace_square": str(s.trace(Q**2)),
    "finite_order_up_to_240": order,
    "all_minpoly_factors_cyclotomic": all_cyclotomic,
    "cyclotomic_factors": cyclotomic_factors,
    "rank_Q2_plus_I": (Q**2+I).rank(),
    "rank_Q4_minus_I": (Q**4-I).rank(),
    "boundary": [
        "Q is native to the paired Gram constructions.",
        "Finite order is not assumed.",
        "No Petrie or physical rotation identification.",
        "No canonical history-to-frame identity claimed."
    ],
}

out = ROOT / "gph048o_dual_golden_product.json"
out.write_text(json.dumps(report, indent=2)+"\n")

print("WROTE:", out)
